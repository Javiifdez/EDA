
import sys
sys.path.append(r'C:\Users\Jabvier Fernandez\OneDrive - UFV\Code\EDA\Implementaciones')
from Clase_nodo import Nodo

class Lista_Enlazada():
    #contructor
    def __init__(self) -> None:
        self.primero = None
        self.ultimo = None
        self.tamanio = None

    #insertar
    def insertar_izquierda(self,valor) -> None:
        nuevo = Nodo(valor)
        if self.tamanio == 0:
            self.primero = nuevo
            self.ultimo = nuevo
        else:
            #es importante el orden para no hacer leaks de memoria
            nuevo.sig = self.primero
            #si lo hacemos al reves el que estaba primero pierde su puntero
            self.primero = nuevo

    #método para imprimir
    def __str__(self):#ahora cuando imprimiamos la variable de clase lista_enlazada se inicializara la funcion
        string = ""
        aux = self.primero #variable aux para ir recorriendo los nodos
        while aux != None:
            str(aux.valor)
            string += aux.valor + " ->"
            aux = aux.sig
        string += "None"
        return string

    #insertar por la derecha
    def insertar_dererecha(self,valor) -> None:
        nuevo = Nodo(valor)
        if self.tamanio == 0:
            self.primero = nuevo
            self.ultimo = nuevo
     
        else:
            self.ultimo = nuevo
"""
https://codeshare.io/w9Qvwx
HACER EL INSERTAR POR LA DERECHA Y LAS DEMAS OPERACIONES
"""

"""

from sys import path
path.append(r'C:\Users\Jabvier Fernandez\OneDrive - UFV\Code\EDA\Implementaciones')
from Clase_lista_enlazada import Lista_Enlazada

"""

class Nodo:
    #contructor
    def __init__(self,valor):#le pasamos un valor al nombre
        self.valor = valor
        self.sig = None

"""
import sys
sys.path.append(r'C:\Users\Jabvier Fernandez\OneDrive - UFV\Code\EDA\Implementaciones')
from Clase_nodo import Nodo

"""
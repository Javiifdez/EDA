"""
Estructura de Datos y Algoritmos | Ing. Matemática | Curso 24/25 
PRÁCTICA 1 – TAD (Clases) Conjunto, Pila, Cola y Lista 
AUTORES: David Sanz Fuertes, Javier Fernandez Meroño
EJERCICIO: 05
DESCRIPCIÓN:  

Este ejercicio implementa una función para buscar y retornar el nodo en la posición 'k' desde el final de una lista enlazada. 
Es similar al método 'buscarIndice(self, indice)', con la diferencia de que en este caso se retorna el nodo completo en lugar de solo su valor.

La función recorre la lista calculando el índice objetivo al restar el largo de la lista y el valor de 'indice' recibido como parámetro. 
En caso de que el índice sea inválido (fuera del rango), se controla la excepción devolviendo 'None'.

El código incluye un ejemplo de uso donde se construye una lista enlazada, se invoca la función 'nodo_k' para obtener el nodo deseado, y se imprime su valor.
"""

from PR1_01 import *

# Función para buscar el nodo en la posición 'k' desde el final de la lista
def nodo_k(lista: 'ListaEnlazada', indice):
    """
    Busca el nodo en la posición 'k' desde el final de la lista enlazada.

    Primero, calcula la posición equivalente contando desde el inicio, restando 
    el tamaño de la lista y el valor de 'indice' menos 1 (por el índice basado en cero).
    Luego, recorre la lista usando un contador para ubicar el nodo deseado. 
    Controla excepciones devolviendo 'None' si el índice es inválido.
    
    Retorna:
        Nodo: El nodo en la posición deseada o 'None' si el índice no es válido.
    """
    indice = len(lista) - (indice - 1)

    if indice <= 0:  # Si el índice no es válido, retorna None
        return None
    
    aux = lista.primero
    contador = 1

    while contador < indice:
        aux = aux.sig
        contador += 1
    
    return aux

if __name__ == "__main__":

    l1 = ListaEnlazada()

    l1.insertarPrimero(10)
    l1.insertarPrimero(9)
    l1.insertarPrimero(4)
    l1.insertarPrimero(3)
    l1.insertarPrimero(20)


    print(f"Lista: {l1}")

    print(F"\nNodo en la posicion 2 (empezando por la derecha): {nodo_k(l1, 2)}")

    print(f"\nValor de dicho nodo: {nodo_k(l1, 2).valor}")

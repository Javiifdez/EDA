

"""
Estructura de Datos y Algoritmos | Ing. Matemática | Curso 24/25 
PRÁCTICA 1 – TAD (Clases) Conjunto, Pila, Cola y Lista 
AUTORES: David Sanz Fuertes, Javier Fernandez Meroño
EJERCICIO: 01
EXPLICACIONES:  

Esta implementación de una lista enlazada utiliza índices que comienzan en 1, en lugar de 0, para facilitar un acceso más intuitivo en algunos contextos. 

La clase `ListaEnlazada` incluye métodos de inserción, eliminación, concatenación, y búsqueda de elementos.

- El método __len__ devuelve la longitud de la lista mediante la función predefinida len() en python, no se recorre la lista ya que se mantiene un contador actualizado en cada manipulacion de la longitud de la lista.
- La eliminación de nodos (eliminarIzquierda) emplea un nodo ficticio (dummy) que simplifica el manejo de casos especiales, como la eliminación del primer nodo.
- Los métodos de inserción (insertarPrimero, insertarUltimo, insertarIndice) permiten añadir elementos en posiciones específicas.

Las funciones quedan explicadas en su correspondiente docstring debajo de cada funcion. 

Al final se hace una serie de pruebas en el programa principal para mostrar que el codigo funciona de manera correcta.
"""


class Nodo:
    def __init__(self, valor):
        self.valor = valor
        self.sig = None

class ListaEnlazada:
    def __init__(self):
        self.primero = None
        self.ultimo = None
        self._largo = 0 # Lo definimos como un atributo protegido
    
    # Metodo para mostrar todos los elementos de la lista en formato string --> utilizacion print('lista')
    def __str__(self):
        string = ""
        aux = self.primero 
        while aux is not None:
            string += str(aux.valor) + " -> "
            aux = aux.sig        
        string += "None"  
        return string 
    
    # Funcion que retorna el contador del largo --> el metodo __len__ permite que se pueda utilizar la funcion len(self) para asi calcular el largo
    def __len__(self):
        return self._largo
        
    # Funcion que comprueba si la lista es vacia
    def esVacia(self):
        return (self.primero == None) and (self.ultimo == None)
    
    # Añade un valor al inicio de la lista
    def insertarPrimero(self, valor):
        '''
        Inserta un nuevo nodo con el valor dado al inicio de la lista enlazada.

        Funcionalidad:
            - Crea un nuevo nodo con el valor proporcionado.
            - Comprueba si la lista está vacía:
                - Si está vacía, el nuevo nodo se asigna como 'primero' y 'último' nodo de la lista.
            - Si la lista no está vacía, el nuevo nodo se enlaza al inicio de la lista.
            - Aumenta el contador de longitud ('_largo') de la lista en 1.
        '''
        nuevo = Nodo(valor)
        if self.esVacia():
            self.ultimo = nuevo

        nuevo.sig = self.primero
        self.primero = nuevo
        self._largo += 1


    # Añade un valor al final de la lista
    def insertarUltimo(self, valor):
        '''
        Inserta un nuevo nodo con el valor dado al final de la lista enlazada.

        Funcionalidad:
            - Crea un nuevo nodo con el valor proporcionado.
            - Verifica si la lista está vacía:
                - Si está vacía, asigna el nuevo nodo como el primero de la lista.
                - Si no está vacía, ajusta el puntero 'sig' del nodo actual 'ultimo' para que apunte al nuevo nodo.
            - Actualiza 'self.ultimo' para que apunte al nuevo nodo, asegurando que es el último de la lista.
            - Aumenta el contador de longitud ('_largo') de la lista en 1.
        '''

        nuevo = Nodo(valor)
        if self.esVacia():
            self.primero = nuevo
        else:
            self.ultimo.sig = nuevo

        self.ultimo = nuevo
        self._largo += 1

        # Función para agregar un elemento a la lista en una posición específica (índice)
    def insertarIndice(self, valor, indice):
        '''
        Inserta un nuevo nodo con el valor dado en la posición indicada en la lista enlazada.

        Funcionalidad:
            - Si la lista está vacía o el índice es negativo o cero:
                - Inserta el nodo al inicio de la lista.
            - Si el índice es mayor o igual al tamaño de la lista:
                - Inserta el nodo al final de la lista.
            - Si el índice es válido (dentro del rango de la lista):
                - Recorre la lista hasta el nodo anterior a la posición deseada.
                - Inserta el nuevo nodo en la posición indicada, ajustando los punteros.
        '''
        if self.esVacia() or indice <= 1: 
            self.insertarPrimero(valor)
        elif indice > self._largo:
            self.insertarUltimo(valor)
        else:
            nuevo = Nodo(valor)
            aux = self.primero
            for val in range(indice - 2): 
                aux = aux.sig

            nuevo.sig = aux.sig
            aux.sig = nuevo
            self._largo += 1


    # Funcion para buscar primer valor de la lista
    def buscarPrimero(self):
        """Primero comprueba que el valor exista, si no existe retorna None"""
        if self.primero:
            return self.primero.valor
        else:
            return None
        
    # Funcion para buscar el ultimo valor de la lista
    def buscarUltimo(self):
        """Primero comprueba que el valor exista, si no existe retorna None"""
        if self.ultimo:
            return self.ultimo.valor
        else:
            return None

    # Función para buscar el valor de un Nodo en la lista por su índice
    def buscarIndice(self, indice):
        '''
        Busca y devuelve el valor de un nodo en una posición específica de la lista.

        Funcionalidad:
            - Verifica si el índice está dentro del rango válido de la lista (de 1 a 'self._largo').
            - Si el índice es válido, recorre la lista hasta llegar al nodo en la posición indicada.
            - Devuelve el valor del nodo encontrado.

        Excepciones:
            - Si el índice es menor que 1 (ya que las listas en esta implementacion comienzan en 1) o mayor que el tamaño de la lista, 
            la función devuelve 'None' para indicar que el índice no es válido.

        '''
        if indice < 1 or indice > self._largo:
            return None

        aux = self.primero

        for val in range(indice - 1): # Recorre hasta indice-1 ya que la implementacion va de 1 a len(lista)
            aux = aux.sig
            
        return aux.valor

    # Funcion para eliminar valor segun el indice, empezando por la izquierda de la ListaEnlazada
    def eliminarIzquierda(self, indice):
        """
        Elimina el nodo en una posición específica de la lista enlazada usando un nodo ficticio para simplificar el proceso.

        Funcionalidad:
            - Usa un nodo ficticio (dummy) que apunta al primer nodo, lo que permite eliminar el primer nodo sin necesidad de 
            condiciones especiales.
            - Un puntero auxiliar ('aux') avanza hasta el nodo anterior al que se quiere eliminar, y luego salta el nodo a eliminar 
            ajustando su referencia.
            - Si el nodo eliminado era el primero, 'self.primero' se actualiza al nuevo primer nodo.
            - Si el nodo eliminado era el último, 'self.ultimo' se actualiza al nuevo último nodo.

        Excepciones:
            - Si el índice es inválido (menor que 1 o mayor que el tamaño de la lista), el método no realiza ninguna acción.
            - Si se elimina el único nodo de la lista, 'self.primero' y 'self.ultimo' se ajustan a 'None', dejando la lista vacía.
            - La longitud de la lista ('self._largo') se reduce en 1 cada vez que se elimina un nodo.

        """

        if indice < 1 or indice > len(self):
            return

        dummy = Nodo(None)
        dummy.sig = self.primero
        aux = dummy  

        for val in range(indice - 1): 
            aux = aux.sig

        aux.sig = aux.sig.sig 
        self.primero = dummy.sig 
        if aux.sig is None: 
            self.ultimo = aux
        self._largo -= 1
    
        
    # Funcion para eliminar un valor empezando por la derecha
    def eliminarDerecha(self, indice):
        """Utilizamos la funcion previa para eliminar el valor empezando por la derecha"""
        return self.eliminarIzquierda(len(self) - indice + 1) 

    # Función para concatenar una lista enlazada con la lista actual
    def concatenar(self, lista: 'ListaEnlazada'):
        '''
        Concatena otra lista enlazada al final de la lista actual.

        Funcionalidad:
            - Verifica si la lista actual está vacía:
                - Si está vacía, asigna los nodos 'primero' y 'ultimo' de la lista externa a la lista actual.
            - Si la lista actual no está vacía y la lista externa tampoco:
                - Ajusta el puntero 'sig' del nodo 'ultimo' actual para que apunte al primer nodo de la lista externa.
                - Actualiza 'self.ultimo' para que apunte al último nodo de la lista externa.
            - Aumenta el contador de longitud ('_largo') sumando el tamaño de la lista externa.

        Excepciones:
            - No hay excepciones específicas en esta función; siempre concatena la lista externa, ya sea vacía o con elementos.
        '''
        if self.esVacia():
            self.primero = lista.primero
        else:
            self.ultimo.sig = lista.primero

        self.ultimo = lista.ultimo
        self._largo += len(lista)




if __name__ == "__main__":

    # Crear una lista enlazada y agregar elementos al final
    l1 = ListaEnlazada()
    lista_valores = [10, 123, 99, 912, 88, 190, 4560]

    print("### Creación de la lista enlazada inicial ###")
    for valor in lista_valores:
        l1.insertarUltimo(valor)
    print("Lista después de insertar elementos al final:", l1)

    # Prueba de inserción en el inicio
    print("\n### Prueba de inserción al inicio ###")
    l1.insertarPrimero(500)
    print("Lista después de insertar 500 al inicio:", l1)

    # Prueba de inserción en una posición específica (índice 3)
    print("\n### Prueba de inserción en índice 3 ###")
    l1.insertarIndice(250, 3)
    print("Lista después de insertar 250 en el índice 3:", l1)

    # Prueba de inserción en una posición fuera de los límites (al final)
    print("\n### Prueba de inserción en un índice mayor al tamaño (último lugar) ###")
    l1.insertarIndice(1000, len(l1) + 2)  # Debería agregarse al final
    print("Lista después de insertar 1000 al final:", l1)

    # Prueba de eliminación en el primer índice
    print("\n### Prueba de eliminación en el primer índice ###")
    l1.eliminarIzquierda(1)
    print("Lista después de eliminar el primer elemento:", l1)

    # Prueba de eliminación en el índice 3
    print("\n### Prueba de eliminación en el índice 3 ###")
    l1.eliminarIzquierda(3)
    print("Lista después de eliminar el elemento en índice 3:", l1)

    # Prueba de eliminación en el último índice
    print("\n### Prueba de eliminación en el último índice ###")
    l1.eliminarIzquierda(len(l1))
    print("Lista después de eliminar el último elemento:", l1)

    # Prueba de concatenación con otra lista
    print("\n### Prueba de concatenación con otra lista enlazada ###")
    l2 = ListaEnlazada()
    lista_valores_2 = [7, 14, 21]
    for valor in lista_valores_2:
        l2.insertarUltimo(valor)
    print("Lista 2 a concatenar:", l2)

    l1.concatenar(l2)
    print("Lista después de concatenar con otra lista:", l1)

    # Prueba de búsqueda del primer y último elemento
    print("\n### Pruebas de búsqueda ###")
    print("Primer elemento:", l1.buscarPrimero())
    print("Último elemento:", l1.buscarUltimo())

    # Prueba de búsqueda por índice
    print("\n### Prueba de búsqueda por índice ###")
    print("Elemento en el índice 2:", l1.buscarIndice(2))
    print("Elemento en el índice 5:", l1.buscarIndice(5))
    print("Elemento en el índice 10:", l1.buscarIndice(10))  # Índice fuera de rango

"""
Estructura de Datos y Algoritmos | Ing. Matemática | Curso 24/25 
PRÁCTICA 1 – TAD (Clases) Conjunto, Pila, Cola y Lista 
AUTORES: David Sanz Fuertes, Javier Fernandez Meroño
EJERCICIO: 07
DESCRIPCIÓN:

Esta práctica implementa una clase 'Libros' con atributos para el título, autor y año de publicación, 
tal como se describe en el enunciado. 

La función 'autores_unicos(lista)' recibe una lista de objetos 'Libros' y devuelve un conjunto con los 
nombres de los autores únicos, eliminando así cualquier autor repetido.

En el bloque principal, se crea una lista de libros de diferentes autores (algunos repetidos) para probar 
el código, verificando que la función identifica correctamente los autores únicos.
"""

class Libros:
    def __init__(self, titulo, autor, anio):
        self.titulo = titulo
        self.autor = autor
        self.anio = anio

def autores_unicos(lista: list):  
    """
    Recibe una lista de objetos 'Libros' y retorna un conjunto de autores únicos.

    Recorre cada objeto 'Libros' en la lista y almacena el atributo 'autor' en una lista auxiliar, 
    que luego se convierte en un conjunto para eliminar duplicados y obtener solo los autores únicos.

    Retorna:
        set: Conjunto de autores únicos.
    """
    resultado = []
    for valor in lista:
        resultado.append(valor.autor)
    return set(resultado)

if __name__ == "__main__":

    # Creación de varios libros, algunos con autores repetidos, para comprobar la funcionalidad
    libro1 = Libros("Cien años de soledad", "Gabriel García Márquez", 1967)
    libro2 = Libros("1984", "George Orwell", 1949)
    libro3 = Libros("El amor en los tiempos del cólera", "Gabriel García Márquez", 1985)
    libro4 = Libros("Orgullo y prejuicio", "Jane Austen", 1813)
    libro5 = Libros("Rebelión en la granja", "George Orwell", 1945)
    libro6 = Libros("Don Quijote de la Mancha", "Miguel de Cervantes", 1605)

    # Se pasa la lista de libros a la función y se imprime el conjunto de autores únicos
    libros = (libro1, libro2, libro3, libro4, libro5, libro6)
    print(f"Los autores únicos son: {autores_unicos(libros)}")


"""
Estructura de Datos y Algoritmos | Ingeniería Matemática | Curso 24/25
PRÁCTICA 1 – TAD (Clases): Conjunto, Pila, Cola y Lista
AUTORES: David Sanz Fuertes, Javier Fernandez Meroño
EJERCICIO: 04

EXPLICACIÓN:

En este ejercicio, hemos implementado un método de doble puntero para encontrar el nodo en la mitad de una lista enlazada,
logrando una complejidad de O(n/2), que se simplifica a O(n), ya que recorremos la lista solo una vez.

Para alcanzar esta eficiencia, empleamos dos punteros:
- rapido, que avanza dos nodos en cada iteración.
- despacio, que avanza un nodo en cada iteración.

De esta manera, cuando `rapido` llega al final de la lista, 'despacio' se encuentra en la posición media de la misma. 

Este método es eficiente, ya que permite localizar el nodo central sin necesidad de recorrer la lista varias veces.

Para más detalles, el funcionamiento del código se encuentra explicado en el docstring de la función justo abajo.

"""



from PR1_01 import *

def mitad_lista(lista: ListaEnlazada):
    """
    Devuelve el valor del nodo en la mitad de una lista enlazada.

    Usa dos punteros (rapido y despacio) para recorrer la lista:
    - rapido avanza dos nodos por iteración.
    - despacio avanza un nodo por iteración.
    
    Cuando rapido alcanza el final de la lista, despacio estará en el nodo de la mitad.

    - Si la lista tiene un número impar de nodos, devuelve el valor del nodo central.
    - Si la lista tiene un número par de nodos, devuelve el valor del nodo justo después de la mitad.

    Si la lista está vacía, genera una excepción y devuelve None.
    """

    if lista.esVacia():
        return None
    
    rapido = lista.primero
    despacio = lista.primero

    while rapido and rapido.sig:
        despacio = despacio.sig
        rapido = rapido.sig.sig

    return despacio.valor

    
if __name__=="__main__":
    l1 = ListaEnlazada()

    
    # l1.insertarPrimero(210)
    l1.insertarPrimero(90)
    l1.insertarPrimero(10)
    l1.insertarPrimero(9)
    l1.insertarPrimero(4)
    l1.insertarPrimero(3)
    l1.insertarPrimero(20)
   
    print(f"Lista: {l1}")

    print(F"\nMitad de la lista: {mitad_lista(l1)}")
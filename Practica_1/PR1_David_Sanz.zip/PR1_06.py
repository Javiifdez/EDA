"""
Estructura de Datos y Algoritmos | Ing. Matemática | Curso 24/25 
PRÁCTICA 1 – TAD (Clases) Conjunto, Pila, Cola y Lista 
AUTORES: David Sanz Fuertes, Javier Fernandez Meroño
EJERCICIO: 06
DESCRIPCIÓN:

Este programa toma dos listas enlazadas ordenadas ('ListaEnlazada') y las combina en una única lista enlazada ordenada. 
La ordenación se realiza comparando los valores de los nodos de cada lista y añadiéndolos de forma ordenada a una lista auxiliar,
que se retorna al final.

Cada paso del código está detallado en la función y su docstring para mayor claridad.
"""

from PR1_01 import *

def ordenar(lista1: 'ListaEnlazada', lista2: 'ListaEnlazada'):
    """
    Combina dos listas enlazadas ordenadas en una única lista enlazada ordenada.

    Si una de las listas está vacía, se utiliza el método 'concatenar' de 'ListaEnlazada' para unirlas directamente.
    Si ambas listas tienen elementos, se inicializa una lista de resultado y se comparan los nodos de ambas listas, 
    agregándolos de forma ordenada a la lista de resultado. 
    Una vez que se terminan los nodos de una lista, se agrega el resto de la otra lista.

    Retorna:
        ListaEnlazada: Una nueva lista enlazada que contiene los elementos de ambas listas, en orden.
    """
    if lista1.esVacia() or lista2.esVacia():
        return lista1.concatenar(lista2)  # Utiliza el método 'concatenar' de la clase ListaEnlazada
    else:
        resultado = ListaEnlazada()
        aux_resultado = Nodo(-1)  # Nodo auxiliar para facilitar la construcción de la lista
        resultado.primero = aux_resultado
        aux1 = lista1.primero
        aux2 = lista2.primero

        while aux1 is not None and aux2 is not None:
            if aux1.valor < aux2.valor:
                aux_resultado.sig = aux1
                aux1 = aux1.sig
            else:
                aux_resultado.sig = aux2
                aux2 = aux2.sig
            aux_resultado = aux_resultado.sig

    # Agrega los elementos restantes de la lista no vacía
    if aux1 is None:
        aux_resultado.sig = aux2
        resultado.ultimo = lista2.ultimo
    elif aux2 is None:
        aux_resultado.sig = aux1
        resultado.ultimo = lista1.ultimo
                        
    resultado.primero = resultado.primero.sig  # Ajusta el primer nodo de la lista de resultado

    return resultado

if __name__ == "__main__":

    l1 = ListaEnlazada()
    l2 = ListaEnlazada()

    l1.insertarPrimero(100)
    l1.insertarPrimero(80)
    l1.insertarPrimero(11)
    l1.insertarPrimero(8)
    l1.insertarPrimero(5)
    l1.insertarPrimero(4)
    l1.insertarPrimero(3)
    l1.insertarPrimero(1)

    l2.insertarPrimero(10)
    l2.insertarPrimero(10)
    l2.insertarPrimero(9)
    l2.insertarPrimero(8)
    l2.insertarPrimero(6)
    l2.insertarPrimero(3)
    
    print(f"\nLista 1: {l1}")
    print(f"\nLista 2: {l2}")

    # Concatenamos las listas ordenadas y las reordenamos
    ord1 = ordenar(l1, l2)

    print(f"\nLista resultante ordenada: {ord1}")
    print(f"\nPrimer valor de la lista resultante: {ord1.primero.valor}")
    
    print(f"\nUltimo valor de la lista resultante: {ord1.ultimo.valor}")


"""
Estructura de Datos y Algoritmos | Ing. Matemática | Curso 24/25 
PRÁCTICA 1 – TAD (Clases) Conjunto, Pila, Cola y Lista 
AUTORES: David Sanz Fuertes, Javier Fernandez Meroño
EJERCICIO: 02
DESCRIPCIÓN:

Esta función recibe dos conjuntos de asignaturas aprobadas por dos estudiantes y realiza tres operaciones:
- 'resultado1': Obtiene las asignaturas aprobadas por ambos estudiantes mediante la intersección de los conjuntos.
- 'resultado2': Obtiene las asignaturas aprobadas solo por el primer estudiante y no por el segundo.
- 'resultado3': Calcula la unión de ambos conjuntos para obtener todas las asignaturas aprobadas por al menos uno de los estudiantes.

En el bloque principal, se crean dos conjuntos de ejemplo y se llama a la función 'solucion()', imprimiendo los resultados.
"""

def solucion(conjunto1: set, conjunto2: set):
    """
    'resultado1' --> Asignaturas aprobadas por ambos estudiantes
    'resultado2' --> Asignaturas aprobadas solo por el primer estudiante, pero no por el segundo
    'resultado3' --> Asignaturas aprobadas por al menos uno de los dos estudiantes
    """
    resultado1 = conjunto1.intersection(conjunto2)
    resultado2 = conjunto1.difference(conjunto2)
    resultado3 = conjunto1.union(conjunto2)

    return resultado1, resultado2, resultado3

if __name__ == "__main__":
    estudiante1 = {'Matemáticas', 'Física', 'Química'} 
    estudiante2 = {'Física', 'Biología', 'Química'}
    a, b, c = solucion(estudiante1, estudiante2)
    print(f"\nAmbos estudiantes han aprobado: {a}")
    print(f"\nSolo ha aprobado el primero, pero no el segundo: {b}")
    print(f"\nAprobado al menos uno: {c}")

"""
Estructura de Datos y Algoritmos | Ing. Matemática | Curso 24/25 
PRÁCTICA 1 – TAD (Clases) Conjunto, Pila, Cola y Lista 
AUTORES: David Sanz Fuertes, Javier Fernandez Meroño
EJERCICIO: 08
DESCRIPCIÓN:

Este código define una clase 'Usuario' que permite gestionar amigos y solicitudes de amistad para cada usuario. 
Cada usuario tiene un conjunto de amigos y una cola de solicitudes de amistad.

- El método 'aceptar_solicitud(self)' procesa la solicitud de amistad más antigua. Si el usuario de la solicitud 
  no está ya en la lista de amigos, se añade y se elimina de las solicitudes pendientes. Si ya es amigo, solo se 
  informa sin modificar la lista de amigos ni las solicitudes.

- El método 'aniadir(self, nombre)' agrega una nueva solicitud de amistad al final de la cola de solicitudes.

En el bloque principal, se crea un usuario y se prueba la gestión de solicitudes y amigos:
se agregan solicitudes de amistad, se aceptan una por una, y se muestran las listas de amigos y solicitudes pendientes 
en diferentes momentos.
"""

from collections import deque

class Usuario:
    def __init__(self, nombre):
        self.nombre = nombre
        self.amigos = set()
        self.solicitudes = deque()

    def aceptar_solicitud(self):
        """
        Acepta la solicitud de amistad más antigua en la cola de solicitudes.
        
        - Si el usuario de la solicitud no está en la lista de amigos, lo añade como amigo y lo elimina de las 
        solicitudes. 
        
        - Si el usuario ya es amigo, solo informa de ello. 
        
        - Si no hay solicitudes pendientes, muestra un mensaje indicando que no hay solicitudes disponibles.
        """
        if self.solicitudes:
            cima = self.solicitudes[0]
            if cima not in self.amigos:
                self.amigos.add(cima)
                self.solicitudes.popleft()
                print(f"\n{cima} ha sido añadid@ a la lista de amig@s\n")
                print(f"Solicitudes restantes: {self.solicitudes}")
            else:
                print(f"El usuario {cima} ya estaba en la lista de amigos\n")
                print(f"Solicitudes restantes: {self.solicitudes}")
        else:
            print("No tiene solicitudes disponibles")

    def aniadir(self, nombre):
        """
        Agrega una nueva solicitud de amistad al final de la cola de solicitudes.
        """
        print(f"\nSe ha añadido a {nombre} a la cola de solicitudes")
        self.solicitudes.append(nombre)

if __name__ == "__main__":
    # Crear una instancia de usuario
    user1 = Usuario("Enrique")

    print("\n--------------------------------\n")

    # Agregar solicitudes de amistad
    user1.aniadir("Ana")
    user1.aniadir("Carlos")
    user1.aniadir("Beatriz")

    print("\n--------------------------------\n")

    # Verificar las solicitudes pendientes
    print(f"\nSolicitudes de amistad pendientes para {user1.nombre}: {user1.solicitudes}\n")

    print("\n--------------------------------\n")

    # Aceptar solicitudes de amistad una por una
    user1.aceptar_solicitud()  # Acepta la solicitud de "Ana"
    user1.aceptar_solicitud()  # Acepta la solicitud de "Carlos"

    print("\n--------------------------------\n")

    # Agregar otra solicitud de amistad
    user1.aniadir("David")

    print("\n--------------------------------\n")

    # Verificar las solicitudes pendientes y amigos después de aceptar algunas
    print(f"\nAmigos de {user1.nombre}: {user1.amigos}")
    print(f"\nSolicitudes de amistad pendientes: {user1.solicitudes}\n")

    print("\n--------------------------------\n")

    # Intentar aceptar las solicitudes restantes
    user1.aceptar_solicitud()  # Acepta la solicitud de "Beatriz"
    user1.aceptar_solicitud()  # Acepta la solicitud de "David"
    user1.aceptar_solicitud()  # No debería haber más solicitudes

    print("\n--------------------------------\n")

    # Estado final de amigos y solicitudes
    print(f"\nEstado final de amigos de {user1.nombre}: {user1.amigos}")
    print(f"\nSolicitudes de amistad pendientes: {user1.solicitudes}")

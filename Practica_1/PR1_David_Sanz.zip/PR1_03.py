"""
Estructura de Datos y Algoritmos | Ing. Matemática | Curso 24/25 
PRÁCTICA 1 – TAD (Clases) Conjunto, Pila, Cola y Lista 
AUTORES: David Sanz Fuertes, Javier Fernandez Meroño
EJERCICIO: 03
DESCRIPCIÓN:

En este ejercicio, se utiliza una pila auxiliar para invertir una cadena de caracteres. 
Cada carácter del string original se agrega a la pila, y posteriormente se recorre la pila 
para ir extrayendo cada elemento de la cima, construyendo la cadena en orden inverso en 
una variable auxiliar.

El proceso continúa hasta que la pila auxiliar esté vacía, momento en el cual se retorna 
la cadena invertida almacenada en la variable auxiliar.
"""



def invertir_cadena(cadena):
    string = ""
    intermedio = []
    for valor in cadena:
        intermedio.append(valor)

    while intermedio:
        string += intermedio[-1]
        intermedio.pop()

    return string


if __name__=="__main__":
    cadena = "javier"
    cadena1 = "Estructura de Datos y Algoritmos"
    print(invertir_cadena(cadena))
    print(invertir_cadena(cadena1))

